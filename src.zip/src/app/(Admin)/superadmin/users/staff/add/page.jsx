"use client";

import "./add-staff.css";

import { useState } from "react";
import { useRouter } from "next/navigation";



import Swal from "sweetalert2";
import { createStaffUser } from "@/services/user.service";

const BUTTON_COLOR = "#2563eb";


export default function AddStaff() {

    const router = useRouter();

    const [image, setImage] = useState(null);
    const [fullName, setFullName] = useState("");
    const [email, setEmail] = useState("");
    const [phone, setPhone] = useState("");
    const [department, setDepartment] = useState("");
    const [role, setRole] = useState("staff");
    const [status, setStatus] = useState("Active");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");

    const [loading, setLoading] = useState(false);


    const handleSubmit = async (e) => {

        e.preventDefault();

        if (password !== confirmPassword) {
            Swal.fire({
              icon: "error",
              title: "Error",
              text: "Passwords do not match.",
              confirmButtonColor: BUTTON_COLOR,
            });
            return;
        }

        setLoading(true);

        try {

            let profileImage = "";

            if (image) {

                const formData = new FormData();

                formData.append("file", image);
                formData.append("upload_preset", "YOUR_UPLOAD_PRESET");

                const response = await fetch(
                    "https://api.cloudinary.com/v1_1/YOUR_CLOUD_NAME/image/upload",
                    {
                        method: "POST",
                        body: formData,
                    }
                );

                const data = await response.json();

                profileImage = data.secure_url;

            }

            const result = await createStaffUser({
                fullName,
                email,
                phone,
                department,
                role,
                status,
                password,
                photoURL: profileImage,
            });

            if (!result.ok) throw new Error(result.message);

            Swal.fire({
              icon: "success",
              title: "Success",
              text: "Staff added successfully.",
              confirmButtonColor: BUTTON_COLOR,
            });

            setTimeout(() => {
                router.push("/superadmin/users/staff");
            }, 1500);

        } catch (error) {

            Swal.fire({
              icon: "error",
              title: "Error",
              text: error.message,
              confirmButtonColor: BUTTON_COLOR,
            });

        }

        setLoading(false);

    };

    return (

        <div className="add-staff-page content-wrapper">


            <div className="form-card">

                <h1>Add Staff</h1>

                <form onSubmit={handleSubmit}>

                    <div className="form-grid">

                        <div className="form-group">
                            <label>Profile Image</label>
                            <input
                                type="file"
                                onChange={(e) =>
                                    setImage(e.target.files[0])
                                }
                            />
                        </div>

                        <div className="form-group">
                            <label>Full Name</label>
                            <input
                                type="text"
                                value={fullName}
                                onChange={(e) =>
                                    setFullName(e.target.value)
                                }
                                required
                            />
                        </div>

                        <div className="form-group">
                            <label>Email</label>
                            <input
                                type="email"
                                value={email}
                                onChange={(e) =>
                                    setEmail(e.target.value)
                                }
                                required
                            />
                        </div>

                        <div className="form-group">
                            <label>Phone</label>
                            <input
                                type="text"
                                value={phone}
                                onChange={(e) =>
                                    setPhone(e.target.value)
                                }
                                required
                            />
                        </div>

                        <div className="form-group">
                            <label>Department</label>

                            <select
                                value={department}
                                onChange={(e) =>
                                    setDepartment(e.target.value)
                                }
                            >
                                <option value="">Select</option>
                                <option>Customer Support</option>
                                <option>Finance</option>
                                <option>Marketing</option>
                                <option>Operations</option>
                                <option>Technical Support</option>
                                <option>Security</option>
                            </select>

                        </div>

                        <div className="form-group">
                            <label>Role</label>

                            <select
                                value={role}
                                onChange={(e) =>
                                    setRole(e.target.value)
                                }
                            >
                                <option value="staff">
                                    Staff
                                </option>

                                <option value="admin">
                                    Admin
                                </option>

                            </select>

                        </div>

                        <div className="form-group">
                            <label>Password</label>

                            <input
                                type="password"
                                value={password}
                                onChange={(e) =>
                                    setPassword(e.target.value)
                                }
                                required
                            />

                        </div>

                        <div className="form-group">
                            <label>Confirm Password</label>

                            <input
                                type="password"
                                value={confirmPassword}
                                onChange={(e) =>
                                    setConfirmPassword(e.target.value)
                                }
                                required
                            />

                        </div>

                        <div className="form-group">
                            <label>Status</label>

                            <select
                                value={status}
                                onChange={(e) =>
                                    setStatus(e.target.value)
                                }
                            >
                                <option>Active</option>
                                <option>Blocked</option>
                            </select>

                        </div>

                    </div>

                    <button
                        className="save-btn"
                        disabled={loading}
                    >
                        {loading
                            ? "Saving..."
                            : "Add Staff"}
                    </button>

                </form>

            </div>

        </div>

    );

}