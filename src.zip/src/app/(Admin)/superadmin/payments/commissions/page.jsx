"use client";

import "./commissions.css";

import { useEffect, useState } from "react";
import Link from "next/link";



import {
    FaSearch,
    FaPercentage,
    FaEye,
} from "react-icons/fa";
import Swal from "sweetalert2";
import { listCommissions } from "@/services/payment.service";

const BUTTON_COLOR = "#2563eb";


export default function CommissionsPage() {

    const [commissions, setCommissions] = useState([]);
    const [search, setSearch] = useState("");


    useEffect(() => {

        loadCommissions();

    }, []);

    const loadCommissions = async () => {

        try {

            const snapshot = await listCommissions();

            const data = snapshot;

            setCommissions(data);

        } catch (err) {

            console.log(err);

            Swal.fire({
              icon: "error",
              title: "Error",
              text: "Unable to load commissions.",
              confirmButtonColor: BUTTON_COLOR,
            });

        }

    };

    const filtered = commissions.filter(item =>

        item.hotelName
            ?.toLowerCase()
            .includes(search.toLowerCase()) ||

        item.ownerName
            ?.toLowerCase()
            .includes(search.toLowerCase()) ||

        item.bookingNumber
            ?.toLowerCase()
            .includes(search.toLowerCase())

    );

    return (

        <div className="commission-page content-wrapper">


            <div className="page-header">

                <div>

                    <h1>Commissions</h1>

                    <p>

                        Track commissions earned from hotel bookings.

                    </p>

                </div>

            </div>

            <div className="toolbar">

                <div className="search-box">

                    <FaSearch />

                    <input
                        type="text"
                        placeholder="Search..."
                        value={search}
                        onChange={(e) =>
                            setSearch(e.target.value)
                        }
                    />

                </div>

            </div>

            <div className="table-wrapper">

                <table>

                    <thead>

                        <tr>

                            <th>Booking</th>

                            <th>Hotel</th>

                            <th>Owner</th>

                            <th>Total</th>

                            <th>Commission %</th>

                            <th>Commission</th>

                            <th>Payout</th>

                            <th>Status</th>

                            <th>Action</th>

                        </tr>

                    </thead>

                    <tbody>

                        {

                            filtered.length === 0 ?

                                <tr>

                                    <td colSpan="9">

                                        No commission records found.

                                    </td>

                                </tr>

                                :

                                filtered.map(item => (<tr key={item.id}>

                                    <td>

                                        {item.bookingNumber}

                                    </td>

                                    <td>

                                        {item.hotelName}

                                    </td>

                                    <td>

                                        {item.ownerName}

                                    </td>

                                    <td>

                                        ₦{Number(item.totalBooking || 0).toLocaleString()}

                                    </td>

                                    <td>

                                        <div className="percent">

                                            <FaPercentage />

                                            <span>

                                                {item.commissionRate || 0}%

                                            </span>

                                        </div>

                                    </td>

                                    <td>

                                        ₦{Number(item.commission || 0).toLocaleString()}

                                    </td>

                                    <td>

                                        ₦{Number(item.payoutAmount || 0).toLocaleString()}

                                    </td>

                                    <td>

                                        <span
                                            className={
                                                item.status
                                                    ?.toLowerCase()
                                                    .replace(/\s+/g, "-")
                                            }
                                        >

                                            {item.status}

                                        </span>

                                    </td>

                                    <td>

                                        <Link
                                            href={`/superadmin/payments/commissions/${item.id}`}
                                            className="view"
                                        >

                                            <FaEye />

                                        </Link>

                                    </td>

                                </tr>

                                ))

                        }

                    </tbody>

                </table>

            </div>

        </div>

    );

}