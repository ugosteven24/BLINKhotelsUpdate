"use client";

import "./activity-logs.css";

import { useEffect, useState } from "react";
import Link from "next/link";



import {
    FaArrowLeft,
    FaSearch,
    FaTrash,
    FaHistory,
    FaUserShield,
    FaCheckCircle,
    FaTimesCircle,
    FaClock,
    FaFilter,
} from "react-icons/fa";
import Swal from "sweetalert2";
import { deleteRecord, listRecords } from "@/services/cms.service";

const BUTTON_COLOR = "#2563eb";


export default function ActivityLogsPage() {

    const [logs, setLogs] = useState([]);

    const [loading, setLoading] = useState(true);

    const [search, setSearch] = useState("");

    const [filter, setFilter] = useState("All");


    useEffect(() => {

        loadLogs();

    }, []);

    const loadLogs = async () => {

        try {

            const snapshot = await listRecords("activityLogs");

            const data = snapshot;

            setLogs(data);

        }

        catch (err) {

            console.log(err);

            Swal.fire({
              icon: "error",
              title: "Error",
              text: "Unable to load activity logs.",
              confirmButtonColor: BUTTON_COLOR,
            });

        }

        finally {

            setLoading(false);

        }

    };

    const deleteLog = async (id) => {

        if (

            !confirm(

                "Delete this activity log?"

            )

        ) return;

        try {

            await deleteRecord("activityLogs", id);

            setLogs(

                logs.filter(

                    item => item.id !== id

                )

            );

            Swal.fire({
              icon: "success",
              title: "Success",
              text: "Activity log deleted.",
              confirmButtonColor: BUTTON_COLOR,
            });

        }

        catch {

            Swal.fire({
              icon: "error",
              title: "Error",
              text: "Unable to delete log.",
              confirmButtonColor: BUTTON_COLOR,
            });

        }

    };

    const filteredLogs = logs.filter(log => {

        const matchSearch =

            log.user

                ?.toLowerCase()

                .includes(

                    search.toLowerCase()

                ) ||

            log.action

                ?.toLowerCase()

                .includes(

                    search.toLowerCase()

                );

        const matchFilter =

            filter === "All"

                ? true

                : log.status === filter;

        return (

            matchSearch &&

            matchFilter

        );

    });

    return (

        <div className="content-wrapper activity-page">


            <div className="page-header">

                <div>

                    <h1>

                        Activity Logs

                    </h1>

                    <p>

                        Monitor every action performed by administrators and staff.

                    </p>

                </div>

                <Link

                    href="/superadmin/security"

                    className="back-btn"

                >

                    <FaArrowLeft />

                    Back

                </Link>

            </div>

            <div className="stats-grid">

                <div className="stat-card">

                    <div className="icon blue">

                        <FaHistory />

                    </div>

                    <div>

                        <h4>Total Activities</h4>

                        <h2>

                            {logs.length}

                        </h2>

                    </div>

                </div>

                <div className="stat-card">

                    <div className="icon green">

                        <FaCheckCircle />

                    </div>

                    <div>

                        <h4>Successful</h4>

                        <h2>

                            {

                                logs.filter(

                                    l =>

                                        l.status === "Success"

                                ).length

                            }

                        </h2>

                    </div>

                </div>

                <div className="stat-card">

                    <div className="icon red">

                        <FaTimesCircle />

                    </div>

                    <div>

                        <h4>Failed</h4>

                        <h2>

                            {

                                logs.filter(

                                    l =>

                                        l.status === "Failed"

                                ).length

                            }

                        </h2>

                    </div>

                </div>

                <div className="stat-card">

                    <div className="icon orange">

                        <FaUserShield />

                    </div>

                    <div>

                        <h4>Admins</h4>

                        <h2>

                            {

                                new Set(

                                    logs.map(

                                        l =>

                                            l.user

                                    )

                                ).size

                            }

                        </h2>

                    </div>

                </div>

            </div>

            <div className="toolbar">

                <div className="search-box">

                    <FaSearch />

                    <input

                        type="text"

                        placeholder="Search activity..."

                        value={search}

                        onChange={(e) =>

                            setSearch(

                                e.target.value

                            )

                        }

                    />

                </div>

                <div className="filter-box">

                    <FaFilter />

                    <select

                        value={filter}

                        onChange={(e) =>

                            setFilter(

                                e.target.value

                            )

                        }

                    >

                        <option>

                            All

                        </option>

                        <option>

                            Success

                        </option>

                        <option>

                            Failed

                        </option>

                    </select>

                </div>

            </div>

            <div className="table-wrapper">

                <table>

                    <thead>

                        <tr>

                            <th>User</th>

                            <th>Action</th>

                            <th>Module</th>

                            <th>Status</th>

                            <th>Date</th>

                            <th>Action</th>

                        </tr>

                    </thead>

                    <tbody>

                        {

                            loading ?

                                <tr>

                                    <td colSpan="6">

                                        Loading...

                                    </td>

                                </tr>

                            :

                            filteredLogs.length === 0 ?

                                <tr>

                                    <td colSpan="6">

                                        No activity logs found.

                                    </td>

                                </tr>

                            :

                            filteredLogs.map(log => (

                                <tr

                                    key={log.id}

                                >

                                    <td>

                                        <div className="user-info">

                                            <strong>

                                                {

                                                    log.user

                                                }

                                            </strong>

                                            <small>

                                                {

                                                    log.email

                                                }

                                            </small>

                                        </div>

                                    </td>

                                    <td>

                                        {

                                            log.action

                                        }

                                    </td>

                                    <td>

                                        {

                                            log.module

                                        }

                                    </td>

                                    <td>

                                        <span

                                            className={`status ${log.status?.toLowerCase()}`}

                                        >

                                            {

                                                log.status

                                            }

                                        </span>

                                    </td>

                                    <td>

                                        {

                                            log.createdAt ? new Date(log.createdAt)

                                                .toLocaleString()

                                                :

                                                "-"

                                        }

                                    </td>

                                    <td>

                                        <button

                                            className="delete-btn"

                                            onClick={() =>

                                                deleteLog(

                                                    log.id

                                                )

                                            }

                                        >

                                            <FaTrash />

                                        </button>

                                    </td>

                                </tr>

                            ))

                        }

                    </tbody>

                </table>

            </div>

        </div>

    );

}