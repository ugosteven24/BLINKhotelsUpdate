"use client";

import "./admin-management.css";

import Link from "next/link";
import { useEffect, useState } from "react";



import {
    FaUserShield,
    FaPlus,
    FaSearch,
    FaEdit,
    FaTrash,
    FaEye,
    FaUserCheck,
    FaUserTimes,
    FaUserCog,
} from "react-icons/fa";
import Swal from "sweetalert2";
import { deleteRecord, listRecords } from "@/services/cms.service";

const BUTTON_COLOR = "#2563eb";


export default function AdminManagementPage() {

    const [admins, setAdmins] = useState([]);

    const [loading, setLoading] = useState(true);

    const [search, setSearch] = useState("");


    useEffect(() => {

        loadAdmins();

    }, []);

    const loadAdmins = async () => {

        try {

            const snapshot = await listRecords("admins");

            const data = snapshot;

            setAdmins(data);

        }

        catch (err) {

            console.log(err);

            Swal.fire({
              icon: "error",
              title: "Error",
              text: "Unable to load administrators.",
              confirmButtonColor: BUTTON_COLOR,
            });

        }

        finally {

            setLoading(false);

        }

    };

    const deleteAdmin = async (id) => {

        if (

            !confirm(

                "Delete this administrator?"

            )

        ) return;

        try {

            await deleteRecord("admins", id);

            setAdmins(

                admins.filter(

                    admin => admin.id !== id

                )

            );

            Swal.fire({
              icon: "success",
              title: "Success",
              text: "Administrator deleted.",
              confirmButtonColor: BUTTON_COLOR,
            });

        }

        catch {

            Swal.fire({
              icon: "error",
              title: "Error",
              text: "Unable to delete administrator.",
              confirmButtonColor: BUTTON_COLOR,
            });

        }

    };

    const filteredAdmins = admins.filter(admin =>

        admin.fullName

            ?.toLowerCase()

            .includes(

                search.toLowerCase()

            ) ||

        admin.email

            ?.toLowerCase()

            .includes(

                search.toLowerCase()

            )

    );

    return (

        <div className="content-wrapper admin-page">


            {/* Header */}

            <div className="page-header">

                <div>

                    <h1>

                        Administrator Management

                    </h1>

                    <p>

                        Create, manage and monitor all administrator accounts.

                    </p>

                </div>

                <Link

                    href="/superadmin/admin-management/add"

                    className="add-btn"

                >

                    <FaPlus />

                    Add Administrator

                </Link>

            </div>

            {/* Statistics */}

            <div className="stats-grid">

                <div className="stat-card">

                    <div className="icon blue">

                        <FaUserShield />

                    </div>

                    <div>

                        <h4>

                            Total Admins

                        </h4>

                        <h2>

                            {admins.length}

                        </h2>

                    </div>

                </div>

                <div className="stat-card">

                    <div className="icon green">

                        <FaUserCheck />

                    </div>

                    <div>

                        <h4>

                            Active

                        </h4>

                        <h2>

                            {

                                admins.filter(

                                    admin =>

                                        admin.status === "Active"

                                ).length

                            }

                        </h2>

                    </div>

                </div>

                <div className="stat-card">

                    <div className="icon orange">

                        <FaUserCog />

                    </div>

                    <div>

                        <h4>

                            Super Admins

                        </h4>

                        <h2>

                            {

                                admins.filter(

                                    admin =>

                                        admin.role === "Super Admin"

                                ).length

                            }

                        </h2>

                    </div>

                </div>

                <div className="stat-card">

                    <div className="icon red">

                        <FaUserTimes />

                    </div>

                    <div>

                        <h4>

                            Suspended

                        </h4>

                        <h2>

                            {

                                admins.filter(

                                    admin =>

                                        admin.status === "Suspended"

                                ).length

                            }

                        </h2>

                    </div>

                </div>

            </div>

            {/* Toolbar */}

            <div className="toolbar">

                <div className="search-box">

                    <FaSearch />

                    <input

                        type="text"

                        placeholder="Search administrator..."

                        value={search}

                        onChange={(e) =>

                            setSearch(

                                e.target.value

                            )

                        }

                    />

                </div>

            </div>

            {/* Table */}

            <div className="table-wrapper">

                <table>

                    <thead>

                        <tr>

                            <th>Administrator</th>

                            <th>Role</th>

                            <th>Email</th>

                            <th>Status</th>

                            <th>Created</th>

                            <th>Actions</th>

                        </tr>

                    </thead>

                    <tbody>

                        {

                            loading ?

                                <tr>

                                    <td colSpan="6">

                                        Loading...

                                    </td>

                                </tr>

                                :

                                filteredAdmins.length === 0 ?

                                    <tr>

                                        <td colSpan="6">

                                            No administrators found.

                                        </td>

                                    </tr>

                                    :

                                    filteredAdmins.map(admin => (

                                        <tr key={admin.id}>

                                            <td>

                                                <div className="admin-info">

                                                    <strong>

                                                        {admin.fullName}

                                                    </strong>

                                                    <small>

                                                        {admin.phone}

                                                    </small>

                                                </div>

                                            </td>

                                            <td>

                                                {admin.role}

                                            </td>

                                            <td>

                                                {admin.email}

                                            </td>

                                            <td>

                                                <span

                                                    className={`status ${admin.status?.toLowerCase()}`}

                                                >

                                                    {admin.status}

                                                </span>

                                            </td>

                                            <td>

                                                {

                                                    admin.createdAt ? new Date(admin.createdAt)

                                                            .toLocaleDateString()

                                                        :

                                                        "-"

                                                }

                                            </td>

                                            <td>

                                                <div className="table-actions">

                                                    <Link

                                                        href={`/superadmin/adminmanagement/view/${admin.id}`}

                                                        className="view-btn"

                                                    >

                                                        <FaEye />

                                                    </Link>

                                                    <Link

                                                        href={`/superadmin/adminmanagement/edit/${admin.id}`}

                                                        className="edit-btn"

                                                    >

                                                        <FaEdit />

                                                    </Link>

                                                    <button

                                                        className="delete-btn"

                                                        onClick={() =>

                                                            deleteAdmin(

                                                                admin.id

                                                            )

                                                        }

                                                    >

                                                        <FaTrash />

                                                    </button>

                                                </div>

                                            </td>

                                        </tr>

                                    ))

                        }

                    </tbody>

                </table>

            </div>

        </div>

    );

}