"use client";

import "./reviews.css";

import Link from "next/link";
import { useEffect, useState } from "react";



import {
    FaSearch,
    FaEye,
    FaTrash,
    FaCheck,
    FaStar,
    FaStarHalfAlt,
    FaRegStar,
    FaEyeSlash,
} from "react-icons/fa";
import Swal from "sweetalert2";
import { deleteReview, listReviews, setReviewStatus } from "@/services/review.service";

const BUTTON_COLOR = "#2563eb";


export default function HotelReviewsPage() {

    const [reviews, setReviews] = useState([]);
    const [search, setSearch] = useState("");


    useEffect(() => {

        loadReviews();

    }, []);

    const loadReviews = async () => {

        try {

            const snapshot = await listReviews();

            const data = snapshot;

            setReviews(data);

        } catch (err) {

            console.log(err);

            Swal.fire({
              icon: "error",
              title: "Error",
              text: "Unable to load reviews.",
              confirmButtonColor: BUTTON_COLOR,
            });

        }

    };

    const approveReview = async (id) => {

        try {

            await setReviewStatus(id, "Approved");

            Swal.fire({
              icon: "success",
              title: "Success",
              text: "Review approved.",
              confirmButtonColor: BUTTON_COLOR,
            });

            loadReviews();

        } catch {

            Swal.fire({
              icon: "error",
              title: "Error",
              text: "Unable to approve review.",
              confirmButtonColor: BUTTON_COLOR,
            });

        }

    };

    const hideReview = async (id) => {

        try {

            await setReviewStatus(id, "Hidden");

            Swal.fire({
              icon: "success",
              title: "Success",
              text: "Review hidden.",
              confirmButtonColor: BUTTON_COLOR,
            });

            loadReviews();

        } catch {

            Swal.fire({
              icon: "error",
              title: "Error",
              text: "Unable to hide review.",
              confirmButtonColor: BUTTON_COLOR,
            });

        }

    };

    const deleteReview = async (id) => {

        if (!confirm("Delete this review?"))
            return;

        try {

            await deleteReview(id);

            Swal.fire({
              icon: "success",
              title: "Success",
              text: "Review deleted.",
              confirmButtonColor: BUTTON_COLOR,
            });

            loadReviews();

        } catch {

            Swal.fire({
              icon: "error",
              title: "Error",
              text: "Unable to delete review.",
              confirmButtonColor: BUTTON_COLOR,
            });

        }

    };

    const renderStars = (rating) => {

        const stars = [];

        for (let i = 1; i <= 5; i++) {

            if (rating >= i) {

                stars.push(
                    <FaStar key={i} />
                );

            }

            else if (rating >= i - 0.5) {

                stars.push(
                    <FaStarHalfAlt key={i} />
                );

            }

            else {

                stars.push(
                    <FaRegStar key={i} />
                );

            }

        }

        return stars;

    };

    const filtered = reviews.filter(item =>

        item.hotelName
            ?.toLowerCase()
            .includes(search.toLowerCase()) ||

        item.userName
            ?.toLowerCase()
            .includes(search.toLowerCase()) ||

        item.review
            ?.toLowerCase()
            .includes(search.toLowerCase())

    );

    return (

        <div className="reviews-page content-wrapper">


            <div className="page-header">

                <div>

                    <h1>

                        Hotel Reviews

                    </h1>

                    <p>

                        Moderate guest reviews.

                    </p>

                </div>

            </div>

            <div className="toolbar">

                <div className="search-box">

                    <FaSearch />

                    <input
                        type="text"
                        placeholder="Search review..."
                        value={search}
                        onChange={(e) =>
                            setSearch(e.target.value)
                        }
                    />

                </div>

            </div>

            <div className="table-wrapper">

                <table>

                    <thead>

                        <tr>

                            <th>Hotel</th>

                            <th>Guest</th>

                            <th>Rating</th>

                            <th>Review</th>

                            <th>Status</th>

                            <th>Date</th>

                            <th>Actions</th>

                        </tr>

                    </thead>

                    <tbody>

                        {

                            filtered.length === 0 ?

                                <tr>

                                    <td colSpan="7">

                                        No reviews found.

                                    </td>

                                </tr>

                                :

                                filtered.map(item => (
                                    <tr key={item.id}>

                                        <td>

                                            <div className="hotel-info">

                                                <img
                                                    src={item.hotelImage || "/hotel-placeholder.jpg"}
                                                    alt={item.hotelName}
                                                    className="hotel-img"
                                                />

                                                <div>

                                                    <strong>{item.hotelName}</strong>

                                                    <small>{item.location}</small>

                                                </div>

                                            </div>

                                        </td>

                                        <td>

                                            <div className="guest-info">

                                                <img
                                                    src={item.userImage || "/avatar.png"}
                                                    alt={item.userName}
                                                    className="guest-img"
                                                />

                                                <div>

                                                    <strong>{item.userName}</strong>

                                                    <small>{item.userEmail}</small>

                                                </div>

                                            </div>

                                        </td>

                                        <td>

                                            <div className="stars">

                                                {renderStars(item.rating)}

                                            </div>

                                        </td>

                                        <td className="review-text">

                                            {item.review}

                                        </td>

                                        <td>

                                            <span
                                                className={
                                                    item.status
                                                        ?.toLowerCase()
                                                        .replace(/\s+/g, "-")
                                                }
                                            >

                                                {item.status}

                                            </span>

                                        </td>

                                        <td>

                                            {

                                                item.createdAt ? new Date(item.createdAt)
                                                        .toLocaleDateString()

                                                    : "-"

                                            }

                                        </td>

                                        <td>

                                            <div className="actions">

                                                <Link
                                                    href={`/superadmin/reviews/${item.id}`}
                                                    className="view"
                                                >

                                                    <FaEye />

                                                </Link>

                                                {

                                                    item.status !== "Approved" &&

                                                    <button
                                                        className="approve"
                                                        onClick={() =>
                                                            approveReview(item.id)
                                                        }
                                                    >

                                                        <FaCheck />

                                                    </button>

                                                }

                                                {

                                                    item.status !== "Hidden" &&

                                                    <button
                                                        className="hide"
                                                        onClick={() =>
                                                            hideReview(item.id)
                                                        }
                                                    >

                                                        <FaEyeSlash />

                                                    </button>

                                                }

                                                <button
                                                    className="delete"
                                                    onClick={() =>
                                                        deleteReview(item.id)
                                                    }
                                                >

                                                    <FaTrash />

                                                </button>

                                            </div>

                                        </td>

                                    </tr>

                                ))

                        }

                    </tbody>

                </table>

            </div>

        </div>

    );

}