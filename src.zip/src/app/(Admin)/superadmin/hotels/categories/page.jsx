"use client";

import "./categories.css";

import { useEffect, useState } from "react";



import {
    FaPlus,
    FaEdit,
    FaTrash,
    FaSearch,
    FaSave,
    FaTimes,
} from "react-icons/fa";
import Swal from "sweetalert2";
import { createRecord, deleteRecord, listRecords, updateRecord } from "@/services/cms.service";

const BUTTON_COLOR = "#2563eb";


export default function HotelCategories() {

    const [categories, setCategories] = useState([]);
    const [search, setSearch] = useState("");

    const [name, setName] = useState("");
    const [description, setDescription] = useState("");

    const [editingId, setEditingId] = useState(null);


    useEffect(() => {
        loadCategories();
    }, []);

    const loadCategories = async () => {

        const snapshot = await listRecords("hotel_categories");

        const data = snapshot;

        setCategories(data);

    };

    const saveCategory = async () => {

        if (!name.trim()) {
            Swal.fire({
              icon: "error",
              title: "Error",
              text: "Category name required",
              confirmButtonColor: BUTTON_COLOR,
            });
            return;
        }

        try {

            if (editingId) {

                await updateRecord("hotel_categories", editingId, {
                        name,
                        description,
                    });

                Swal.fire({
                  icon: "success",
                  title: "Success",
                  text: "Category updated.",
                  confirmButtonColor: BUTTON_COLOR,
                });

            } else {

                await createRecord("hotel_categories", {
                        name,
                        description,
                        status: "Active",
                        createdAt: "__SERVER_TIMESTAMP__",
                    });

                Swal.fire({
                  icon: "success",
                  title: "Success",
                  text: "Category added.",
                  confirmButtonColor: BUTTON_COLOR,
                });

            }

            setName("");
            setDescription("");
            setEditingId(null);

            loadCategories();

        } catch {

            Swal.fire({
              icon: "error",
              title: "Error",
              text: "Something went wrong",
              confirmButtonColor: BUTTON_COLOR,
            });

        }

    };

    const editCategory = (category) => {

        setEditingId(category.id);
        setName(category.name);
        setDescription(category.description);

    };

    const removeCategory = async (id) => {

        if (!confirm("Delete category?"))
            return;

        await deleteRecord("hotel_categories", id);

        Swal.fire({
          icon: "success",
          title: "Success",
          text: "Category deleted",
          confirmButtonColor: BUTTON_COLOR,
        });

        loadCategories();

    };

    const filtered = categories.filter(item =>
        item.name
            ?.toLowerCase()
            .includes(search.toLowerCase())
    );

    return (

        <div className="category-page content-wrapper">


            <div className="page-header">

                <h1>Hotel Categories</h1>

            </div>

            <div className="category-card">

                <div className="form-grid">

                    <input
                        type="text"
                        placeholder="Category Name"
                        value={name}
                        onChange={(e) =>
                            setName(e.target.value)
                        }
                    />

                    <input
                        type="text"
                        placeholder="Description"
                        value={description}
                        onChange={(e) =>
                            setDescription(e.target.value)
                        }
                    />

                    <button
                        onClick={saveCategory}
                        className="save-btn"
                    >
                        {editingId ? (
                            <>
                                <FaSave />
                                Update
                            </>
                        ) : (
                            <>
                                <FaPlus />
                                Add Category
                            </>
                        )}
                    </button>

                    {editingId && (

                        <button
                            className="cancel-btn"
                            onClick={() => {

                                setEditingId(null);
                                setName("");
                                setDescription("");

                            }}
                        >

                            <FaTimes />
                            Cancel

                        </button>

                    )}

                </div>

            </div>

            <div className="toolbar">

                <div className="search-box">

                    <FaSearch />

                    <input
                        type="text"
                        placeholder="Search category..."
                        value={search}
                        onChange={(e) =>
                            setSearch(e.target.value)
                        }
                    />

                </div>

            </div>

            <div className="table-wrapper">

                <table>

                    <thead>

                        <tr>

                            <th>Name</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Actions</th>

                        </tr>

                    </thead>

                    <tbody>

                        {filtered.length === 0 ? (

                            <tr>

                                <td colSpan="4">

                                    No categories found.

                                </td>

                            </tr>

                        ) : (

                            filtered.map(category => (

                                <tr key={category.id}>

                                    <td>
                                        {category.name}
                                    </td>

                                    <td>
                                        {category.description}
                                    </td>

                                    <td>

                                        <span className="active">

                                            {category.status}

                                        </span>

                                    </td>

                                    <td>

                                        <div className="actions">

                                            <button
                                                className="edit"
                                                onClick={() =>
                                                    editCategory(category)
                                                }
                                            >

                                                <FaEdit />

                                            </button>

                                            <button
                                                className="delete"
                                                onClick={() =>
                                                    removeCategory(category.id)
                                                }
                                            >

                                                <FaTrash />

                                            </button>

                                        </div>

                                    </td>

                                </tr>

                            ))

                        )}

                    </tbody>

                </table>

            </div>

        </div>

    );

}