"use server";

// In-app notifications for the signed-in user, and administrator broadcasts.

import { query, run, withTransaction } from "@/lib/db/connection";
import { ADMIN_ROLES, requireRole, requireUser } from "@/lib/auth/session";
import { iso, sanitizeDoc } from "@/lib/doc";
import { ServiceError, newId } from "@/lib/service-utils";
import { cleanString } from "@/lib/validation";
import { logActivity } from "@/lib/notify";

const mapNotification = (r) => ({
  id: r.id,
  category: r.category,
  title: r.title,
  message: r.message ?? "",
  icon: r.icon,
  type: r.type,
  read: !!r.is_read,
  actionUrl: r.action_url,
  createdAt: iso(r.created_at),
});

// The old page used a realtime listener; call this on load and on an interval.
export async function listMyNotifications() {
  const user = await requireUser();
  const rows = await query(
    "SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 200",
    [user.id]
  );
  return rows.map(mapNotification);
}

export async function markNotificationRead(id) {
  const user = await requireUser();
  await query("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?", [id, user.id]);
  return { ok: true };
}

export async function markAllNotificationsRead() {
  const user = await requireUser();
  await query("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0", [user.id]);
  return { ok: true };
}

const AUDIENCES = {
  "All Users": null,
  Guests: ["client"],
  "Hotel Owners": ["hotel_owner"],
  Staff: ["staff"],
  Admins: ["admin", "superadmin"],
};

// Admin "Send notification" page: one notification row per recipient.
export async function sendNotification(form) {
  const admin = await requireRole(ADMIN_ROLES);
  const doc = sanitizeDoc(form);

  const title = cleanString(doc.title, 255);
  const message = cleanString(doc.message, 4000);
  if (!title || !message) throw new ServiceError("Title and message are required.");
  if (!Object.hasOwn(AUDIENCES, doc.audience ?? "All Users")) throw new ServiceError("Invalid audience.");

  const roles = AUDIENCES[doc.audience ?? "All Users"];
  const actionUrl = /^\/[A-Za-z0-9/_\-?=&#.]*$/.test(doc.actionUrl ?? "") ? doc.actionUrl : null; // internal paths only
  const sendNow = (doc.status ?? "Send Now") === "Send Now";

  let delivered = 0;
  await withTransaction(async (connection) => {
    if (sendNow) {
      const where = roles ? `AND role IN (${roles.map(() => "?").join(",")})` : "";
      const result = await run(
        connection,
        `INSERT INTO notifications (id, user_id, title, message, category, type, icon, action_url)
         SELECT UUID(), id, ?, ?, 'account', ?, 'notifications', ? FROM users WHERE status = 'active' ${where}`,
        [title, message, cleanString(doc.type, 40) || "General", actionUrl, ...(roles ?? [])]
      );
      delivered = result.affectedRows;
    }

    await run(connection, `INSERT INTO records (collection, id, data) VALUES ('pushNotifications', ?, ?)`, [
      newId(),
      JSON.stringify({
        title, message, audience: doc.audience ?? "All Users", type: doc.type ?? "General",
        priority: doc.priority ?? "Normal", status: doc.status ?? "Send Now",
        sentBy: admin.fullName || admin.email, recipients: delivered, deliveryRate: sendNow ? 100 : 0, clickRate: 0,
      }),
    ]);
    await logActivity(connection, admin, `Sent notification "${title}"`, "Notifications");
  });

  return { ok: true, delivered };
}
