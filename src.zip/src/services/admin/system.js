"use server";

import { revalidatePath } from "next/cache";
import { query, queryOne, execute } from "@/lib/db";
import { requireAdmin, audit, pg, } from "@/lib/guard";


async function getGroup(group) {
  const rows = await query("SELECT setting_key, setting_value FROM platform_settings WHERE group_key=?", [group]);
  return Object.fromEntries(rows.map((r) => [r.setting_key, r.setting_value ?? ""])) ;
}

async function saveGroup(group, fd, allowed, validate) {
  const s = await requireAdmin();
  const next = {};
  for (const k of allowed) next[k] = String(fd.get(k) ?? "").trim();
  const bad = validate?.(next);
  if (bad) return { error: bad } ;
  const old = await getGroup(group);
  for (const k of allowed)
    await execute(
      `INSERT INTO platform_settings (group_key, setting_key, setting_value, updated_by) VALUES (?,?,?,?)
       ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value), updated_by=VALUES(updated_by)`,
      [group, k, next[k], s.userId]);
  await audit(s.userId, `settings.${group}_updated`, "settings", null, old, next);
  revalidatePath("/admin/system");
  return { success: "Settings saved." } ;
}

export async function getPlatformSettings() { await requireAdmin(); return getGroup("platform"); }
export async function getSupportSettings() { await requireAdmin(); return getGroup("support"); }

export async function savePlatformSettingsAction(_, fd) {
  if (fd.get("maintenance_mode") !== "true") fd.set("maintenance_mode", "false");
  return saveGroup("platform", fd,
    ["site_name", "default_currency", "default_commission_rate", "payment_hold_minutes", "approval_window_hours", "tax_rate", "maintenance_mode"],
    (v) => {
      if (!v.site_name) return "Enter a site name.";
      if (!/^[A-Z]{3}$/.test(v.default_currency)) return "Currency must be a 3-letter code, e.g. NGN.";
      const c = Number(v.default_commission_rate); if (!(c >= 0 && c <= 100)) return "Commission must be between 0 and 100.";
      const t = Number(v.tax_rate); if (!(t >= 0 && t <= 100)) return "Tax rate must be between 0 and 100.";
      if (!(Number(v.payment_hold_minutes) > 0) || !(Number(v.approval_window_hours) > 0)) return "Hold and approval windows must be above 0.";
      return null;
    });
}

export async function saveSupportSettingsAction(_, fd) {
  return saveGroup("support", fd, ["support_email", "support_phone", "whatsapp_number", "support_hours", "help_center_url"],
    (v) => (v.support_email && !/^\S+@\S+\.\S+$/.test(v.support_email) ? "Enter a valid support email." : null));
}

export async function listAuditLogs(p) {
  await requireAdmin();
  const { limit, offset, page, pageSize } = pg(p);
  const where = [];
  const args = [];
  if (p.q) { where.push("(a.action LIKE ? OR u.email LIKE ? OR a.entity_type LIKE ?)"); args.push(`%${p.q}%`, `%${p.q}%`, `%${p.q}%`); }
  if (p.entity) { where.push("a.entity_type=?"); args.push(p.entity); }
  const w = where.length ? `WHERE ${where.join(" AND ")}` : "";
  const base = `FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id ${w}`;
  const rows = await query(
    `SELECT a.id, a.action, a.entity_type, a.entity_id, a.old_values, a.new_values, a.ip_address, a.created_at,
            u.email AS actor_email, CONCAT(u.first_name,' ',u.last_name) AS actor_name ${base}
      ORDER BY a.created_at DESC LIMIT ? OFFSET ?`, [...args, limit, offset]);
  const total = (await queryOne(`SELECT COUNT(*) AS c ${base}`, args)).c;
  return { rows, total, page, pageSize };
}

// Admin Activity: per-admin rollup + recent actions by admins only.
export async function getAdminActivity(p = {}) {
  await requireAdmin();
  const like = `%${String(p.q ?? "").trim()}%`;
  const adminWhere = p.q ? "WHERE (u.first_name LIKE ? OR u.last_name LIKE ? OR CONCAT(u.first_name,' ',u.last_name) LIKE ? OR u.email LIKE ?)" : "";
  const recentWhere = p.q ? "WHERE (u.email LIKE ? OR a.action LIKE ? OR a.entity_type LIKE ? OR a.ip_address LIKE ?)" : "";
  const [admins, recent] = await Promise.all([
    query(
      `SELECT u.id, CONCAT(u.first_name,' ',u.last_name) AS name, u.email, r.role_name, u.last_login_at,
              COUNT(a.id) AS actions_30d, MAX(a.created_at) AS last_action
         FROM users u JOIN roles r ON r.id=u.role_id AND r.role_key IN ('super_admin','admin')
         LEFT JOIN audit_logs a ON a.user_id=u.id AND a.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
         ${adminWhere}
        GROUP BY u.id ORDER BY actions_30d DESC`, p.q ? [like, like, like, like] : []),
    query(
      `SELECT a.id, a.action, a.entity_type, a.entity_id, a.created_at, a.ip_address, u.email AS actor_email
         FROM audit_logs a JOIN users u ON u.id=a.user_id JOIN roles r ON r.id=u.role_id AND r.role_key IN ('super_admin','admin')
        ${recentWhere}
        ORDER BY a.created_at DESC LIMIT 300`, p.q ? [like, like, like, like] : []),
  ]);
  return { admins, recent };
}
