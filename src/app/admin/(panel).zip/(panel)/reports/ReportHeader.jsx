import { Header, Filters } from "@/components/admin/ui";

export default function ReportHeader({ title, sub, from, to }) {
  return (<><Header title={title} sub={sub} /><Filters dates values={{ from, to }} /></>);
}
