import { Header } from "@/components/admin/ui";
import RoomTypeForm from "../RoomTypeForm";

export default async function NewRoomType({ params }) {
  const { id } = await params;
  return (<><Header title="Add room type" /><div className="adm-card"><RoomTypeForm hotelId={id} /></div></>);
}
