import ActionForm, { Field } from "@/components/admin/ActionForm";
import SelectField from "@/components/admin/Select";
import { saveRoomTypeAction } from "@/services/admin/rooms";

export default function RoomTypeForm({ hotelId, roomType }) {
  return (
    <ActionForm action={saveRoomTypeAction} submit={roomType ? "Save room type" : "Create room type"}>
      <input type="hidden" name="hotel_id" value={hotelId} />
      {roomType && <input type="hidden" name="id" value={roomType.id} />}
      <Field name="name" labelText="Name" defaultValue={roomType?.name} required hint="e.g. Deluxe King" />
      <Field name="bed_configuration" labelText="Beds" defaultValue={roomType?.bed_configuration ?? ""} hint="e.g. 1 king bed" />
      <Field name="base_price" labelText="Base price per night" type="number" step="0.01" min="0" defaultValue={roomType?.base_price} required />
      <Field name="currency" labelText="Currency" maxLength={3} defaultValue={roomType?.currency ?? "NGN"} required />
      <Field name="max_adults" labelText="Max adults" type="number" min="1" defaultValue={roomType?.max_adults ?? 2} required />
      <Field name="max_children" labelText="Max children" type="number" min="0" defaultValue={roomType?.max_children ?? 0} />
      <Field name="room_size_sqm" labelText="Room size (m²)" type="number" step="0.01" min="0" defaultValue={roomType?.room_size_sqm ?? ""} />
      <SelectField name="status" labelText="Status" defaultValue={roomType?.status ?? "active"} options={[{ value: "active", label: "Active" }, { value: "inactive", label: "Inactive" }]} />
      <Field as="textarea" full name="description" labelText="Description" defaultValue={roomType?.description ?? ""} />
    </ActionForm>
  );
}
