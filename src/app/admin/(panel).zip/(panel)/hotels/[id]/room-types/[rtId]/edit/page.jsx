import { notFound } from "next/navigation";
import { getRoomType } from "@/services/admin/rooms";
import { Header } from "@/components/admin/ui";
import RoomTypeForm from "../../RoomTypeForm";

export default async function EditRoomType({ params }) {
  const { id, rtId } = await params;
  const data = await getRoomType(Number(id), Number(rtId));
  if (!data) notFound();
  return (<><Header title={`Edit ${data.roomType.name}`} sub={data.roomType.hotel_name} /><div className="adm-card"><RoomTypeForm hotelId={id} roomType={data.roomType} /></div></>);
}
